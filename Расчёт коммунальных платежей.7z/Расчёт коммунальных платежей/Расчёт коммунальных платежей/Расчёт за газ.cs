﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Расчёт_коммунальных_платежей
{
    public partial class Расчёт_за_газ : Form
    {
        public Расчёт_за_газ()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Расчёт_за_газ_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "расчёт_коммунальных_платежейDataSet3.Расчёт_за_газ". При необходимости она может быть перемещена или удалена.
            this.расчёт_за_газTableAdapter1.Fill(this.расчёт_коммунальных_платежейDataSet3.Расчёт_за_газ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "расчёт_коммунальных_платежейDataSet2.Расчёт_за_газ". При необходимости она может быть перемещена или удалена.
            this.расчёт_за_газTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet2.Расчёт_за_газ);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Savebutton2_Click(object sender, EventArgs e)
        {
            try
            {
                this.расчёт_за_газTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet2.Расчёт_за_газ);

            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
         
                }
            }
        }
    }

    

