﻿namespace Расчёт_коммунальных_платежей
{
    partial class Расчёт_за_газ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.dataSet1 = new System.Data.DataSet();
            this.расчёт_коммунальных_платежейDataSet2 = new Расчёт_коммунальных_платежей.Расчёт_коммунальных_платежейDataSet2();
            this.расчётЗаГазBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.расчёт_за_газTableAdapter = new Расчёт_коммунальных_платежей.Расчёт_коммунальных_платежейDataSet2TableAdapters.Расчёт_за_газTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.номерDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеМесяцаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.показательСчётчикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.расчётDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.расчётЗаГазBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.расчёт_коммунальных_платежейDataSet3 = new Расчёт_коммунальных_платежей.Расчёт_коммунальных_платежейDataSet3();
            this.расчёт_за_газTableAdapter1 = new Расчёт_коммунальных_платежей.Расчёт_коммунальных_платежейDataSet3TableAdapters.Расчёт_за_газTableAdapter();
            this.Savebutton2 = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчёт_коммунальных_платежейDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчётЗаГазBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчётЗаГазBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчёт_коммунальных_платежейDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox1.Location = new System.Drawing.Point(16, 12);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(120, 21);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Зимний период";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox2.Location = new System.Drawing.Point(17, 44);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(119, 21);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Летний период";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(214, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(76, 22);
            this.textBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(236, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Показатель счётика";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(296, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 28);
            this.button1.TabIndex = 4;
            this.button1.Text = "Расчёт";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "NewDataSet";
            // 
            // расчёт_коммунальных_платежейDataSet2
            // 
            this.расчёт_коммунальных_платежейDataSet2.DataSetName = "Расчёт_коммунальных_платежейDataSet2";
            this.расчёт_коммунальных_платежейDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // расчётЗаГазBindingSource
            // 
            this.расчётЗаГазBindingSource.DataMember = "Расчёт за газ";
            this.расчётЗаГазBindingSource.DataSource = this.расчёт_коммунальных_платежейDataSet2;
            // 
            // расчёт_за_газTableAdapter
            // 
            this.расчёт_за_газTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерDataGridViewTextBoxColumn,
            this.наименованиеМесяцаDataGridViewTextBoxColumn,
            this.показательСчётчикаDataGridViewTextBoxColumn,
            this.расчётDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.расчётЗаГазBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(448, 287);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // номерDataGridViewTextBoxColumn
            // 
            this.номерDataGridViewTextBoxColumn.DataPropertyName = "Номер";
            this.номерDataGridViewTextBoxColumn.HeaderText = "Номер";
            this.номерDataGridViewTextBoxColumn.Name = "номерDataGridViewTextBoxColumn";
            // 
            // наименованиеМесяцаDataGridViewTextBoxColumn
            // 
            this.наименованиеМесяцаDataGridViewTextBoxColumn.DataPropertyName = "Наименование месяца";
            this.наименованиеМесяцаDataGridViewTextBoxColumn.HeaderText = "Наименование месяца";
            this.наименованиеМесяцаDataGridViewTextBoxColumn.Name = "наименованиеМесяцаDataGridViewTextBoxColumn";
            // 
            // показательСчётчикаDataGridViewTextBoxColumn
            // 
            this.показательСчётчикаDataGridViewTextBoxColumn.DataPropertyName = "Показатель счётчика";
            this.показательСчётчикаDataGridViewTextBoxColumn.HeaderText = "Показатель счётчика";
            this.показательСчётчикаDataGridViewTextBoxColumn.Name = "показательСчётчикаDataGridViewTextBoxColumn";
            // 
            // расчётDataGridViewTextBoxColumn
            // 
            this.расчётDataGridViewTextBoxColumn.DataPropertyName = "Расчёт";
            this.расчётDataGridViewTextBoxColumn.HeaderText = "Расчёт";
            this.расчётDataGridViewTextBoxColumn.Name = "расчётDataGridViewTextBoxColumn";
            // 
            // расчётЗаГазBindingSource1
            // 
            this.расчётЗаГазBindingSource1.DataMember = "Расчёт за газ";
            this.расчётЗаГазBindingSource1.DataSource = this.расчёт_коммунальных_платежейDataSet3;
            // 
            // расчёт_коммунальных_платежейDataSet3
            // 
            this.расчёт_коммунальных_платежейDataSet3.DataSetName = "Расчёт_коммунальных_платежейDataSet3";
            this.расчёт_коммунальных_платежейDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // расчёт_за_газTableAdapter1
            // 
            this.расчёт_за_газTableAdapter1.ClearBeforeFill = true;
            // 
            // Savebutton2
            // 
            this.Savebutton2.Location = new System.Drawing.Point(459, 29);
            this.Savebutton2.Name = "Savebutton2";
            this.Savebutton2.Size = new System.Drawing.Size(75, 23);
            this.Savebutton2.TabIndex = 6;
            this.Savebutton2.Text = "button2";
            this.Savebutton2.UseVisualStyleBackColor = true;
            this.Savebutton2.Click += new System.EventHandler(this.Savebutton2_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(466, 71);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(77, 20);
            this.button2.TabIndex = 7;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Расчёт_за_газ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Khaki;
            this.ClientSize = new System.Drawing.Size(582, 375);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Savebutton2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Name = "Расчёт_за_газ";
            this.Text = "Расчёт_за_газ";
            this.Load += new System.EventHandler(this.Расчёт_за_газ_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчёт_коммунальных_платежейDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчётЗаГазBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчётЗаГазBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расчёт_коммунальных_платежейDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Data.DataSet dataSet1;
        private Расчёт_коммунальных_платежейDataSet2 расчёт_коммунальных_платежейDataSet2;
        private System.Windows.Forms.BindingSource расчётЗаГазBindingSource;
        private Расчёт_коммунальных_платежейDataSet2TableAdapters.Расчёт_за_газTableAdapter расчёт_за_газTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Расчёт_коммунальных_платежейDataSet3 расчёт_коммунальных_платежейDataSet3;
        private System.Windows.Forms.BindingSource расчётЗаГазBindingSource1;
        private Расчёт_коммунальных_платежейDataSet3TableAdapters.Расчёт_за_газTableAdapter расчёт_за_газTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеМесяцаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn показательСчётчикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn расчётDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Savebutton2;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Button button2;
    }
}