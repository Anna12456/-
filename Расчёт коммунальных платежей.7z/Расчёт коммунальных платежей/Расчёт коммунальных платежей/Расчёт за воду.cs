﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Расчёт_коммунальных_платежей
{
    public partial class Расчёт_за_воду : Form
    {
        public Расчёт_за_воду()
        {
            InitializeComponent();
        }

        private void Расчёт_за_воду_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "расчёт_коммунальных_платежейDataSet4.Расчёт_за_воду". При необходимости она может быть перемещена или удалена.
            this.расчёт_за_водуTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet4.Расчёт_за_воду);
  
        }
 

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
;
        }
        private void button1_Click(object sender, EventArgs e)
        
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            this.Validate();
            this.dataGridView1.EndEdit();
                  this.расчёт_за_водуTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet4.Расчёт_за_воду);

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            this.Validate();
            this.dataGridView1.EndEdit();
            this.расчёт_за_водуTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet4.Расчёт_за_воду);
        }
     
       





    }
}

