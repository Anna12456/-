﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Расчёт_коммунальных_платежей
{
    public partial class Расчёт_за_телефонную_связь : Form
    {
        public Расчёт_за_телефонную_связь()
        {
            InitializeComponent();
        }

        private void Расчёт_за_телефонную_связь_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "расчёт_коммунальных_платежейDataSet1.Расчёт_за_телекоммуникации". При необходимости она может быть перемещена или удалена.
            this.расчёт_за_телекоммуникацииTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet1.Расчёт_за_телекоммуникации);

        }
    }
}
