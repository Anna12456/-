﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Расчёт_коммунальных_платежей
{
    public partial class Расчёт_за_свет : Form
    {
        public Расчёт_за_свет()
        {
            InitializeComponent();
        }

        private void Расчёт_за_свет_Load(object sender, EventArgs e)

        {

            // TODO: данная строка кода позволяет загрузить данные в таблицу "расчёт_коммунальных_платежейDataSet5.Расчёт_за_свет". При необходимости она может быть перемещена или удалена.
            this.расчёт_за_светTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet5.Расчёт_за_свет);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            this.Validate();
            this.dataGridView1.EndEdit();
            this.расчёт_за_светTableAdapter.Fill(this.расчёт_коммунальных_платежейDataSet5.Расчёт_за_свет);
        }
    }
}
