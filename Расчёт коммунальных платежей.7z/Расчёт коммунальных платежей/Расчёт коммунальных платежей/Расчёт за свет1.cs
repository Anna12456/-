﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Расчёт_коммунальных_платежей
{
    class Расчёт_за_свет1
    {
    
    }
}
